const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SG_MAIL_API_KEY);

exports.handler = async(event) => {
    let statusCode = '200';

    let body = {
        message: 'Invoice email has been successfully sent.'
    };

    try {
        const key = event.key;
        const email = event.email;
        const created = event.created;
        const expiry = event.expiry;

        const msg = {
            to: email,
            from: process.env.FROM_MAIL,
            templateId: process.env.MAIL_TEMPLATE_ID,
            dynamicTemplateData: {
                license_key: key,
                purchase_date: created,
                valid_until: expiry
            }
        };

        await sgMail.send(msg).catch((error) => {
            throw error;
        });
    }
    catch (e) {
        console.log("Error: " + e.message);
        statusCode = '400';

        body = {
            error: e.message
        };
    }

    return {
        'headers': {
            'Content-Type': 'application/json',
        },
        'statusCode': statusCode,
        'body': JSON.stringify(body)
    };
};
