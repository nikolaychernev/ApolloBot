const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async(event) => {
    let statusCode = '200';
    let body = {};

    try {
        const key = event['queryStringParameters']['key'];
        const account = event['queryStringParameters']['account'];

        let params = {
            TableName: 'license',
            Key: {
                'key': key
            }
        };

        let license = await docClient.get(params).promise();

        if (Object.keys(license).length !== 0) {
            license = license.Item;

            if (license.accounts.length < license.accountsLimit && !license.accounts.includes(account) && account !== 'undefined') {
                license.accounts.push(account);

                params = {
                    TableName: 'license',
                    Item: license
                };

                await docClient.put(params).promise();
            }

            let expiry = new Date(license.expiry).getTime();
            let currentDate = new Date().getTime();

            if (currentDate > expiry) {
                license.expired = true;
                license.expiryText = 'License has expired';
            }
            else {
                let millisecondsDiff = expiry - currentDate;
                let hoursDiff = millisecondsDiff / 1000 / 60 / 60;
                let daysDiff = hoursDiff / 24;

                license.expired = false;
                license.expiryText = `License expires in ${Math.floor(daysDiff)} days, ${Math.floor(hoursDiff % 24)} hours with ${license.accounts.length} of ${license.accountsLimit} accounts used`;
            }
        }

        body.license = license;
    }
    catch (e) {
        console.log("Error: " + e.message);
        statusCode = '400';

        body = {
            error: e.message
        };
    }

    return {
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'statusCode': statusCode,
        'body': JSON.stringify(body)
    };
};
