const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda();
const { v4: uuidv4 } = require('uuid');

exports.handler = async(event) => {
    let statusCode = '200';

    let body = {
        message: 'License created successfully.'
    };

    try {
        const key = uuidv4().toUpperCase();
        const email = event.email;
        const created = new Date();

        let expiry = new Date();
        expiry.setMonth(expiry.getMonth() + 1);

        const params = {
            TableName: 'license',
            Item: {
                'key': key,
                'email': email,
                'created': created.toISOString(),
                'expiry': expiry.toISOString(),
                'accounts': [],
                'accountsLimit': 3
            }
        };

        await docClient.put(params).promise();

        params.Item.created = created.toUTCString();
        params.Item.expiry = expiry.toUTCString();

        await lambda.invoke({
                FunctionName: 'sendInvoiceEmail',
                InvocationType: 'Event',
                Payload: JSON.stringify(params.Item)
            })
            .promise();
    }
    catch (e) {
        console.log("Error: " + e.message);
        statusCode = '400';

        body = {
            error: e.message
        };
    }

    return {
        'headers': {
            'Content-Type': 'application/json'
        },
        'statusCode': statusCode,
        'body': JSON.stringify(body)
    };
};
