const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async(event) => {
    let statusCode = '200';
    let body = {};

    try {
        const account = event['queryStringParameters']['account'];

        let params = {
            TableName: 'trial',
            Key: {
                'account': account
            }
        };

        let trial = await docClient.get(params).promise();

        if (Object.keys(trial).length === 0) {
            let expiry = new Date();
            expiry.setDate(expiry.getDate() + 7);

            params = {
                TableName: 'trial',
                Item: {
                    'account': account,
                    'expiry': expiry.toISOString()
                }
            };

            await docClient.put(params).promise();
            trial = params;
        }

        body.trial = trial.Item;

        let expiry = new Date(body.trial.expiry).getTime();
        let currentDate = new Date().getTime();

        if (currentDate > expiry) {
            body.trial.expired = true;
            body.trial.expiryText = 'Trial has expired';
        }
        else {
            let millisecondsDiff = expiry - currentDate;
            let hoursDiff = millisecondsDiff / 1000 / 60 / 60;
            let daysDiff = hoursDiff / 24;

            body.trial.expired = false;
            body.trial.expiryText = `Trial expires in ${Math.floor(daysDiff)} days, ${Math.floor(hoursDiff % 24)} hours`;
        }
    }
    catch (e) {
        console.log("Error: " + e.message);
        statusCode = '400';

        body = {
            error: e.message
        };
    }

    return {
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'statusCode': statusCode,
        'body': JSON.stringify(body)
    };
};
