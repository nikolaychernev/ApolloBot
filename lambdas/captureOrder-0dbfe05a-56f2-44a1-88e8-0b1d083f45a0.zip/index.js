const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();
const checkout = require('@paypal/checkout-server-sdk');

function client() {
    return new checkout.core.PayPalHttpClient(environment());
}

function environment() {
    let clientId = process.env.PAYPAL_CLIENT_ID;
    let clientSecret = process.env.PAYPAL_CLIENT_SECRET;

    return new checkout.core.LiveEnvironment(
        clientId, clientSecret
    );
}

exports.handler = async(event) => {
    let statusCode = '302';
    let location = 'https://apollo-bot.com/successful-payment.html';

    try {
        const token = event.queryStringParameters.token;
        console.log("Token: " + token);
        const request = new checkout.orders.OrdersCaptureRequest(token);

        const capture = await client().execute(request);
        const email = capture.result.payer.email_address;

        await lambda.invoke({
                FunctionName: 'createLicense',
                InvocationType: 'Event',
                Payload: JSON.stringify({
                    'email': email
                })
            })
            .promise();
    }
    catch (e) {
        console.log("Error: " + e.message);
        location = 'https://apollo-bot.com/failed-payment.html';
    }

    return {
        'headers': {
            'Location': location,
        },
        'statusCode': statusCode
    };
};
