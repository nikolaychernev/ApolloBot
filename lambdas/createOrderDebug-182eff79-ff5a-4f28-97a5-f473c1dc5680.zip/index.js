const checkout = require('@paypal/checkout-server-sdk');

function client() {
    return new checkout.core.PayPalHttpClient(environment());
}

function environment() {
    let clientId = process.env.PAYPAL_CLIENT_ID;
    let clientSecret = process.env.PAYPAL_CLIENT_SECRET;

    return new checkout.core.SandboxEnvironment(
        clientId, clientSecret
    );
}

exports.handler = async(event) => {
    let statusCode = '200';
    let body = {};

    try {
        const request = new checkout.orders.OrdersCreateRequest();

        request.requestBody({
            intent: 'CAPTURE',
            purchase_units: [{
                amount: {
                    currency_code: 'USD',
                    value: '3.99'
                }
            }],
            application_context: {
                shipping_preference: 'NO_SHIPPING',
                user_action: 'PAY_NOW',
                return_url: 'https://7h8kgzi3wk.execute-api.us-east-2.amazonaws.com/default/captureOrderDebug'
            }
        });

        const order = await client().execute(request);
        body.approveUrl = order.result.links.filter(l => l.rel === 'approve')[0].href;
    }
    catch (e) {
        console.log("Error: " + e.message);
        statusCode = '400';

        body = {
            error: e.message
        };
    }

    return {
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'statusCode': statusCode,
        'body': JSON.stringify(body)
    };
};
